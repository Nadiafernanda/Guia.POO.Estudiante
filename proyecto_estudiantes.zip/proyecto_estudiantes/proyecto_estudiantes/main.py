"""Vistas de consola: solicitan datos y presentan resultados de los controladores."""

from shared.herramientas import (
    RESPUESTAS_SI, imprimir_titulo, imprimir_exito, imprimir_error,
    imprimir_info, confirmar
)
from views import ClienteController, EstudianteController


class MenuClientes:
    """Vista base que comparte las operaciones de menu entre clientes y estudiantes."""

    # Configuracion que las subclases pueden cambiar sin duplicar las operaciones.
    TITULO = "SISTEMA DE CLIENTES"
    ANCHO = 90
    NOMBRE_REGISTRO = "cliente"
    PROMPT_BUSQUEDA = "Nombre, apellido, email, telefono o ciudad: "
    CONTROLADOR = ClienteController

    def __init__(self, controlador=None):
        """Inicializa el estado del menu y relaciona cada tecla con una accion."""
        # El alias protegido permite que los submenus reutilicen estas operaciones.
        self._controlador = controlador or self.CONTROLADOR
        self.__controlador = self._controlador
        self.__activo = True
        self.__opciones = {
            "1": (f"Crear {self.NOMBRE_REGISTRO}", self.crear),
            "2": ("Ver todos", self.listar),
            "3": ("Buscar", self.buscar),
            "4": ("Ver por id", self.ver_por_id),
            "5": ("Actualizar", self.actualizar),
            "0": ("Salir", self.salir),
        }
        # Cada menu agrega sus opciones especificas sin duplicar las comunes.
        self.__opciones.update(self.opciones_adicionales())

    def opciones_adicionales(self):
        """Devuelve las acciones especificas de clientes; las subclases las reemplazan."""
        return {
            "6": ("Estadisticas", self.estadisticas),
            "7": ("Eliminar", self.eliminar),
        }

    @staticmethod
    def pausa():
        """Detiene la pantalla hasta que el usuario presione Enter."""
        input("\nPresione Enter para continuar...")

    @staticmethod
    def pedir_entero(etiqueta):
        """Solicita un id positivo y vuelve a preguntar si el dato no es valido."""
        while True:
            try:
                valor = int(input(etiqueta))
                if valor > 0:
                    return valor
            except ValueError:
                pass
            imprimir_error("Ingrese un id entero mayor que cero")

    @staticmethod
    def mostrar_resultado(exito, mensaje):
        """Muestra el mensaje del controlador con el estilo de exito o error."""
        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)

    def mostrar_tabla(self, clientes):
        """Imprime una tabla con los campos principales de los clientes."""
        print(f"{'ID':<5}{'NOMBRE':<22}{'EMAIL':<28}{'CIUDAD':<15}{'TELEFONO':<12}")
        print("-" * self.ANCHO)
        for cliente in clientes:
            print(f"{cliente.id:<5}{cliente.nombre_completo:<22}{cliente.email:<28}{cliente.ciudad:<15}{cliente.telefono:<12}")
        print("-" * self.ANCHO)
        imprimir_info(f"Total: {len(clientes)} cliente(s)")

    def pedir_registro(self):
        """Pide un id y obtiene el objeto correspondiente mediante el controlador."""
        # Obtiene el registro por id con el controlador configurado para este menu.
        id_registro = self.pedir_entero(f"Id del {self.NOMBRE_REGISTRO}: ")
        registro = self.__controlador.obtener(id_registro)
        if registro is None:
            imprimir_error(f"No existe un {self.NOMBRE_REGISTRO} con id {id_registro}")
        return registro

    def crear(self):
        """Pide cada campo del modelo, solicita su creacion y muestra el resultado."""
        imprimir_titulo(f"CREAR {self.NOMBRE_REGISTRO.upper()}")
        datos = {}
        # El modelo determina los campos; asi la vista no repite su configuracion.
        for campo in self.__controlador.MODELO.CAMPOS:
            datos[campo] = input(f"{campo.capitalize()}: ")
        self.mostrar_resultado(*self.__controlador.crear(datos))
        self.pausa()

    def listar(self):
        """Solicita todos los registros y delega su presentacion a la tabla."""
        imprimir_titulo(f"LISTA DE {self.NOMBRE_REGISTRO.upper()}S")
        clientes = self.__controlador.listar()
        if not clientes:
            imprimir_info(f"Todavia no hay {self.NOMBRE_REGISTRO}s. Use la opcion 1 para crear el primero.")
        else:
            self.mostrar_tabla(clientes)
        self.pausa()

    def buscar(self):
        """Lee un criterio y muestra las coincidencias devueltas por el controlador."""
        imprimir_titulo(f"BUSCAR {self.NOMBRE_REGISTRO.upper()}")
        termino = input(self.PROMPT_BUSQUEDA).strip()
        while not termino:
            imprimir_error("El termino de busqueda no puede estar vacio")
            termino = input(self.PROMPT_BUSQUEDA).strip()
        encontrados = self.__controlador.buscar(termino)
        if not encontrados:
            imprimir_info(f"Ningun {self.NOMBRE_REGISTRO} coincide con '{termino}'.")
        else:
            self.mostrar_tabla(encontrados)
        self.pausa()

    def ver_por_id(self):
        """Presenta todos los datos de un registro encontrado por su identificador."""
        imprimir_titulo(f"VER {self.NOMBRE_REGISTRO.upper()}")
        registro = self.pedir_registro()
        if registro is not None:
            for clave, valor in registro.a_diccionario().items():
                print(f"  {clave.capitalize():<12}: {valor}")
            if hasattr(registro, "dominio_email"):
                print(f"  Dominio del email: {registro.dominio_email}")
        self.pausa()

    def actualizar(self):
        """Pide los nuevos valores; los campos vacios se conservan sin cambios."""
        imprimir_titulo(f"ACTUALIZAR {self.NOMBRE_REGISTRO.upper()}")
        registro = self.pedir_registro()
        if registro is None:
            return self.pausa()

        imprimir_info(f"Editando a {registro.nombre_completo}")
        print("Deje en blanco el campo que no quiera cambiar.\n")
        cambios = {}
        for campo in self.__controlador.MODELO.CAMPOS:
            actual = getattr(registro, campo)
            nuevo = input(f"{campo.capitalize()} [{actual}]: ").strip()
            if nuevo:
                cambios[campo] = nuevo
        self.mostrar_resultado(*self.__controlador.actualizar(registro.id, cambios))
        self.pausa()

    def eliminar(self):
        """Solicita confirmacion antes de pedir al controlador que elimine el registro."""
        imprimir_titulo(f"ELIMINAR {self.NOMBRE_REGISTRO.upper()}")
        registro = self.pedir_registro()
        if registro is None:
            return self.pausa()

        imprimir_info(f"Se eliminara: {registro}")
        respuesta = input("Confirma la eliminacion? (si/no): ").strip().lower()
        while respuesta not in RESPUESTAS_SI and respuesta not in ("no", "n"):
            imprimir_error("Responda si o no")
            respuesta = input("Confirma la eliminacion? (si/no): ").strip().lower()
        if respuesta in RESPUESTAS_SI:
            self.mostrar_resultado(*self.__controlador.eliminar(registro.id))
        else:
            imprimir_info("Operacion cancelada")
        self.pausa()

    def estadisticas(self):
        """Muestra las estadisticas definidas por el controlador de clientes."""
        imprimir_titulo("ESTADISTICAS CLIENTES")
        datos = self.__controlador.estadisticas()
        print(f"  Total    : {datos['total']}")
        print(f"  Ciudades : {', '.join(datos['ciudades']) or '-'}")
        print(f"  Dominios : {', '.join(datos['dominios']) or '-'}")
        self.pausa()

    def salir(self):
        """Cambia el estado para que termine el bucle del menu."""
        self.__activo = False
        imprimir_info("Hasta luego.")

    def mostrar_menu(self):
        """Imprime todas las teclas y acciones disponibles en este menu."""
        imprimir_titulo(self.TITULO)
        for tecla, (texto, _metodo) in self.__opciones.items():
            print(f"  {tecla:>2}. {texto}")
        print()

    def ejecutar(self):
        """Lee opciones y ejecuta la accion asociada hasta que se elija salir."""
        while self.__activo:
            self.mostrar_menu()
            tecla = input("Seleccione una opcion: ").strip()
            if tecla not in self.__opciones:
                imprimir_error("Opcion no valida")
                self.pausa()
                continue
            _texto, metodo = self.__opciones[tecla]
            metodo()


class MenuEstudiantes(MenuClientes):
    """Menu de estudiantes que reutiliza las operaciones comunes de MenuClientes."""

    TITULO = "SISTEMA DE ESTUDIANTES"
    ANCHO = 80
    NOMBRE_REGISTRO = "estudiante"
    PROMPT_BUSQUEDA = "Nombre, apellido, email o carnet: "
    CONTROLADOR = EstudianteController

    def __init__(self, controlador=None):
        """Inicializa el menu base con EstudianteController y agrega acciones propias."""
        # La clase base configura el estado y registra las opciones comunes.
        super().__init__(controlador or self.CONTROLADOR)

    def opciones_adicionales(self):
        """Registra eliminar, notas, promedio, materias comunes y estadisticas."""
        return {
            "6": ("Eliminar", self.eliminar),
            "7": ("Agregar nota", self.agregar_nota),
            "8": ("Ver promedio", self.ver_promedio),
            "9": ("Materias en comun", self.materias_en_comun),
            "10": ("Estadisticas", self.estadisticas),
        }

    @staticmethod
    def pedir_numero(etiqueta):
        """Convierte una nota escrita con punto o coma decimal a float."""
        try:
            return float(input(etiqueta).replace(",", "."))
        except ValueError:
            return None

    def mostrar_tabla(self, estudiantes):
        """Muestra la tabla de estudiantes, incluyendo carnet y promedio."""
        print(f"{'ID':<5}{'CARNET':<14}{'NOMBRE':<26}{'EMAIL':<27}{'PROM':<6}")
        print("-" * self.ANCHO)
        for e in estudiantes:
            print(f"{e.id:<5}{e.carnet:<14}{e.nombre_completo:<26}{e.email:<27}{e.promedio:<6}")
        print("-" * self.ANCHO)
        imprimir_info(f"Total: {len(estudiantes)} estudiante(s)")

    def ver_por_id(self):
        """Presenta datos, materias, notas y estado del estudiante seleccionado."""
        imprimir_titulo("VER ESTUDIANTE")
        estudiante = self.pedir_registro()
        if estudiante is not None:
            print(f"  Id       : {estudiante.id}")
            print(f"  Carnet   : {estudiante.carnet}")
            print(f"  Nombre   : {estudiante.nombre_completo}")
            print(f"  Email    : {estudiante.email}")
            print(f"  Materias : {', '.join(sorted(estudiante.materias)) or 'ninguna'}")
            for materia, notas in sorted(estudiante.notas.items()):
                print(f"     {materia}: {notas}")
            print(f"  Promedio : {estudiante.promedio} ({estudiante.estado})")
        self.pausa()

    def agregar_nota(self):
        """Pide materia y nota; el modelo valida el rango antes de guardar."""
        imprimir_titulo("AGREGAR NOTA")
        estudiante = self.pedir_registro()
        if estudiante is None:
            return self.pausa()

        materia = input("Materia: ")
        nota = self.pedir_numero("Nota (0 a 20): ")
        if nota is None:
            imprimir_error("La nota debe ser un numero")
        else:
            self.mostrar_resultado(*self._controlador.agregar_nota(estudiante.id, materia, nota))
        self.pausa()

    def ver_promedio(self):
        """Muestra el promedio y el estado calculado del estudiante seleccionado."""
        imprimir_titulo("PROMEDIO")
        estudiante = self.pedir_registro()
        if estudiante is not None:
            print(f"{estudiante.nombre_completo}: {estudiante.promedio} - {estudiante.estado}")
        self.pausa()

    def materias_en_comun(self):
        """Pide dos ids y presenta la interseccion de sus conjuntos de materias."""
        imprimir_titulo("MATERIAS EN COMUN")
        id_a = self.pedir_entero("Id del primer estudiante: ")
        id_b = self.pedir_entero("Id del segundo estudiante: ")
        if id_a is None or id_b is None:
            imprimir_error("Los ids deben ser numeros enteros")
        else:
            comunes = self._controlador.materias_en_comun(id_a, id_b)
            if comunes is None:
                imprimir_error("Alguno de los ids no existe")
            elif not comunes:
                imprimir_info("No comparten ninguna materia.")
            else:
                print("Materias en comun: " + ", ".join(sorted(comunes)))
        self.pausa()

    def estadisticas(self):
        """Muestra las estadisticas academicas calculadas por el controlador."""
        imprimir_titulo("ESTADISTICAS")
        datos = self._controlador.estadisticas()
        print(f"  Estudiantes        : {datos['total']}")
        print(f"  Promedio general   : {datos['promedio_general']}")
        print(f"  Aprobados          : {', '.join(datos['aprobados']) or 'ninguno'}")
        print(f"  Dominios de email  : {', '.join(datos['dominios']) or '-'}")
        print(f"  Materias ofertadas : {', '.join(datos['materias']) or '-'}")
        self.pausa()

def menu_principal():
    """Permite elegir entre el sistema de clientes, estudiantes o salir."""
    while True:
        imprimir_titulo("MENU PRINCIPAL")
        print("  1. Clientes")
        print("  2. Estudiantes")
        print("  0. Salir")
        opcion = input("Seleccione una opcion: ").strip()

        if opcion == "1":
            # Cada opcion inicia la vista con el controlador de su entidad.
            MenuClientes().ejecutar()
        elif opcion == "2":
            MenuEstudiantes().ejecutar()
        elif opcion == "0":
            imprimir_info("Gracias por usar el sistema.")
            break
        else:
            imprimir_error("Opcion no valida")
            input("\nPresione Enter para continuar...")


if __name__ == "__main__":
    try:
        menu_principal()
    except (KeyboardInterrupt, EOFError):
        print("\nPrograma interrumpido.")
