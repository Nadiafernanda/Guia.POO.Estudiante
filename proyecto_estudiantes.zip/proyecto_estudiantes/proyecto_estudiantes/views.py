import os

from models import Cliente, Estudiante
from shared.json_manager import GestorJSON

# Directorio de este archivo, usado para construir rutas independientes del cwd.
CARPETA = os.path.dirname(os.path.abspath(__file__))
# Cada controlador recibe su propio archivo de datos JSON.
RUTA_CLIENTES = os.path.join(CARPETA, "data", "clientes.json")
RUTA_ESTUDIANTES = os.path.join(CARPETA, "data", "estudiantes.json")


class ClienteController:
    """CONTROLADOR: operaciones CRUD para clientes."""

    # Configuracion que el CRUD usa para trabajar con la clase Cliente.
    MODELO = Cliente
    NOMBRE_REGISTRO = "cliente"
    ARCHIVO = "data/clientes.json"
    CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "telefono", "ciudad")
    CAMPOS_UNICOS = ("email",)
    _gestor = GestorJSON(RUTA_CLIENTES)

    @classmethod
    def _registros(cls):
        """Lee del JSON la lista de diccionarios del modelo configurado."""
        return cls._gestor.leer()

    @classmethod
    def emails_registrados(cls, excepto_id=None):
        """Devuelve los emails existentes, opcionalmente excluyendo un registro."""
        # Devuelve emails normalizados para detectar duplicados con rapidez.
        return cls._valores_registrados("email", excepto_id)

    @classmethod
    def _valores_registrados(cls, campo, excepto_id=None):
        """Construye un conjunto de valores unicos para una busqueda rapida."""
        return {
            cls._normalizar_unico(campo, registro.get(campo, ""))
            for registro in cls._registros()
            if registro["id"] != excepto_id and registro.get(campo)
        }

    @staticmethod
    def _normalizar_unico(campo, valor):
        """Normaliza identificadores antes de compararlos para evitar falsos distintos."""
        # Emails se comparan en minusculas y carnets en mayusculas.
        texto = str(valor).strip()
        return texto.upper() if campo == "carnet" else texto.lower()

    @classmethod
    def siguiente_id(cls):
        """Calcula el siguiente id consecutivo, empezando en 1 si no hay registros."""
        ids = [registro["id"] for registro in cls._registros()]
        return max(ids) + 1 if ids else 1

    @staticmethod
    def _coincide(registro, termino, campos):
        """Indica si el termino aparece en alguno de los campos permitidos."""
        for campo in campos:
            if termino in str(registro.get(campo, "")).lower():
                return True
        return False

    @classmethod
    def _guardar_objeto(cls, objeto):
        """Persiste los cambios de un objeto reemplazando su diccionario en la lista."""
        # Reemplaza en la lista el registro que corresponde al objeto modificado.
        registros = cls._registros()
        for indice, registro in enumerate(registros):
            if registro["id"] == objeto.id:
                registros[indice] = objeto.a_diccionario()
                break
        return cls._gestor.guardar(registros)

    @classmethod
    def crear(cls, datos):
        """Valida datos, crea el modelo y lo agrega al JSON; devuelve (exito, mensaje)."""
        try:
            # Los campos obligatorios se verifican antes de crear el objeto.
            faltantes = [
                campo for campo in cls.MODELO.OBLIGATORIOS
                if not str(datos.get(campo, "")).strip()
            ]
            if faltantes:
                return False, f"Faltan campos obligatorios: {', '.join(faltantes)}"

            # Cada modelo declara sus campos unicos, por ejemplo email y carnet.
            for campo in cls.CAMPOS_UNICOS:
                valor = cls._normalizar_unico(campo, datos.get(campo, ""))
                if valor in cls._valores_registrados(campo):
                    return False, f"Ese {campo} ya esta registrado"

            # Descarta claves que el modelo no reconoce y completa las opcionales.
            valores = {campo: datos.get(campo, "") for campo in cls.MODELO.CAMPOS}
            # El constructor del modelo ejecuta sus propiedades y validaciones.
            objeto = cls.MODELO(cls.siguiente_id(), **valores)

            # Agrega el nuevo registro y escribe la lista completa en el archivo.
            registros = cls._registros()
            registros.append(objeto.a_diccionario())
            if not cls._gestor.guardar(registros):
                return False, "No se pudo escribir el archivo"
            return True, f"{objeto.nombre_completo} creado con id {objeto.id}"
        except ValueError as error:
            return False, str(error)

    @classmethod
    def listar(cls):
        """Convierte cada diccionario guardado en una instancia del modelo."""
        return [cls.MODELO.desde_diccionario(r) for r in cls._registros()]

    @classmethod
    def obtener(cls, id_registro):
        """Busca un objeto por id; devuelve None cuando no existe."""
        for objeto in cls.listar():
            if objeto.id == id_registro:
                return objeto
        return None

    @classmethod
    def buscar(cls, termino):
        """Busca coincidencias parciales sin distinguir mayusculas y minusculas."""
        termino = str(termino).strip().lower()
        if not termino:
            return []
        return [
            cls.MODELO.desde_diccionario(registro)
            for registro in cls._registros()
            if cls._coincide(registro, termino, cls.CAMPOS_BUSCABLES)
        ]

    @classmethod
    def actualizar(cls, id_registro, cambios):
        """Valida y guarda cambios de un registro, devolviendo (exito, mensaje)."""
        try:
            # Rechaza campos que no forman parte del modelo.
            desconocidos = set(cambios) - set(cls.MODELO.CAMPOS)
            if desconocidos:
                return False, f"Campos no validos: {', '.join(sorted(desconocidos))}"
            if not cambios:
                return False, "No se indico ningun cambio"

            objeto = cls.obtener(id_registro)
            if objeto is None:
                return False, f"No existe un {cls.NOMBRE_REGISTRO} con id {id_registro}"

            # Evita duplicados al editar cualquier campo unico del modelo.
            for campo in cls.CAMPOS_UNICOS:
                if campo in cambios:
                    nuevo = cls._normalizar_unico(campo, cambios[campo])
                    if nuevo in cls._valores_registrados(campo, excepto_id=id_registro):
                        return False, f"Ese {campo} ya lo usa otro {cls.NOMBRE_REGISTRO}"

            # setattr pasa por los setters del modelo y mantiene sus validaciones.
            for campo, valor in cambios.items():
                setattr(objeto, campo, valor)

            # Sustituye el diccionario antiguo por el objeto actualizado.
            registros = cls._registros()
            for indice, registro in enumerate(registros):
                if registro["id"] == id_registro:
                    registros[indice] = objeto.a_diccionario()
                    break

            if not cls._gestor.guardar(registros):
                return False, "No se pudo escribir el archivo"
            nombre = cls.NOMBRE_REGISTRO.capitalize()
            return True, f"{nombre} {id_registro} actualizado ({len(cambios)} campo/s)"
        except ValueError as error:
            return False, str(error)

    @classmethod
    def eliminar(cls, id_registro):
        """Elimina por id creando una lista nueva y guarda el resultado."""
        registros = cls._registros()
        quedan = [registro for registro in registros if registro["id"] != id_registro]
        if len(quedan) == len(registros):
            return False, f"No existe un {cls.NOMBRE_REGISTRO} con id {id_registro}"
        if not cls._gestor.guardar(quedan):
            return False, "No se pudo escribir el archivo"
        nombre = cls.NOMBRE_REGISTRO.capitalize()
        return True, f"{nombre} {id_registro} eliminado"

    @classmethod
    def estadisticas(cls):
        """Resume total, ciudades y dominios de email de todos los clientes."""
        registros = cls._registros()
        ciudades = {r.get("ciudad", "") for r in registros if r.get("ciudad")}
        dominios = {r["email"].split("@")[-1] for r in registros if "@" in r["email"]}
        return {
            "total": len(registros),
            "ciudades": sorted(ciudades),
            "dominios": sorted(dominios),
        }


class EstudianteController(ClienteController):
    """CONTROLADOR: las operaciones del sistema. No usa print() ni input().
    Las operaciones que cambian datos devuelven la tupla (exito, mensaje)."""

    # Hereda el CRUD y cambia la configuracion para usar datos de estudiantes.
    MODELO = Estudiante
    NOMBRE_REGISTRO = "estudiante"
    ARCHIVO = "data/estudiantes.json"
    CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "carnet")
    CAMPOS_UNICOS = ("email", "carnet")
    _gestor = GestorJSON(RUTA_ESTUDIANTES)

    @classmethod
    def carnets_registrados(cls, excepto_id=None):
        """Devuelve los carnets existentes, con comparacion insensible a mayusculas."""
        # Reutiliza la consulta generica para el identificador unico del estudiante.
        return cls._valores_registrados("carnet", excepto_id)

    # ===== Operaciones propias de estudiantes =====
    @classmethod
    def agregar_nota(cls, id_estudiante, materia, nota):
        """Agrega una nota usando el modelo y persiste el estudiante actualizado."""
        try:
            objeto = cls.obtener(id_estudiante)
            if objeto is None:
                return False, f"No existe un estudiante con id {id_estudiante}"
            objeto.agregar_nota(materia, nota)
            if not cls._guardar_objeto(objeto):
                return False, "No se pudo escribir el archivo"
            return True, f"Nota {nota} registrada para {objeto.nombre_completo}"
        except ValueError as error:
            return False, str(error)

    @classmethod
    def inscribir_materia(cls, id_estudiante, materia):
        """Inscribe una materia sin duplicados y guarda el cambio en JSON."""
        try:
            objeto = cls.obtener(id_estudiante)
            if objeto is None:
                return False, f"No existe un estudiante con id {id_estudiante}"
            materia = objeto.inscribir_materia(materia)
            if not cls._guardar_objeto(objeto):
                return False, "No se pudo escribir el archivo"
            return True, f"{objeto.nombre_completo} inscrito en {materia}"
        except ValueError as error:
            return False, str(error)

    @classmethod
    def materias_ofertadas(cls):
        """Une las materias de todos los estudiantes en un conjunto sin repetidos."""
        # Union de conjuntos: todas las materias, sin repetir
        todas = set()
        for estudiante in cls.listar():
            todas |= estudiante.materias
        return todas

    @classmethod
    def materias_en_comun(cls, id_a, id_b):
        """Devuelve la interseccion de materias o None si algun id no existe."""
        a = cls.obtener(id_a)
        b = cls.obtener(id_b)
        if a is None or b is None:
            return None
        return a.materias_en_comun(b)

    @classmethod
    def estadisticas(cls):
        """Calcula conteos, aprobados, dominios, promedio global y materias."""
        estudiantes = cls.listar()
        aprobados = [e.nombre_completo for e in estudiantes if e.estado == "Aprobado"]
        dominios = {e.email.split("@")[1] for e in estudiantes}
        promedios = [e.promedio for e in estudiantes]
        return {
            "total": len(estudiantes),
            "aprobados": aprobados,
            "dominios": sorted(dominios),
            "promedio_general": round(sum(promedios) / len(promedios), 2) if promedios else 0,
            "materias": sorted(cls.materias_ofertadas()),
        }
