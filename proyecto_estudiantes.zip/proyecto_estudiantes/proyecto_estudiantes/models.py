class Cliente:
    """MODELO: un cliente valido. Si los datos estan mal, el objeto no se crea."""

    # Nombres de los campos que se guardan para cada cliente.
    CAMPOS = ("nombre", "apellido", "email", "telefono", "ciudad", "direccion")
    # Campos minimos que se deben proporcionar al crear un cliente.
    OBLIGATORIOS = ("nombre", "apellido", "email")
    # Contador compartido: se incrementa cada vez que se crea un Cliente.
    total_creados = 0

    def __init__(self, id_cliente, nombre, apellido, email,
                 telefono="", ciudad="", direccion=""):
        # El doble guion bajo hace que el identificador sea un atributo privado.
        self.__id = id_cliente
        # Se usan los setters para limpiar y validar los datos desde la creacion.
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.telefono = telefono
        self.ciudad = ciudad
        self.direccion = direccion
        # Registra que se creo una nueva instancia de Cliente.
        Cliente.total_creados += 1

    @staticmethod
    def limpiar(texto):
        # Convierte el valor a texto y quita espacios al principio y al final.
        return str(texto).strip()

    @staticmethod
    def es_email_valido(texto):
        # Normaliza el valor antes de revisar su estructura basica.
        texto = str(texto).strip()
        # Un email valido para este modelo debe tener exactamente un @.
        if texto.count("@") != 1:
            return False
        # Separa el nombre de usuario y el dominio para validarlos.
        usuario, dominio = texto.split("@")
        # Exige usuario no vacio, un punto en el dominio y que no termine en punto.
        return len(usuario) > 0 and "." in dominio and not dominio.endswith(".")

    @staticmethod
    def es_telefono_valido(texto):
        # Acepta telefono vacio o exactamente 10 caracteres numericos.
        texto = str(texto).strip()
        return texto == "" or (texto.isdigit() and len(texto) == 10)

    # @property permite consultar el id como cliente.id, sin parentesis.
    # No hay setter, por lo que el id no se puede cambiar desde la interfaz publica.
    @property
    def id(self):
        return self.__id

    # Getter: devuelve el nombre privado del objeto.
    @property
    def nombre(self):
        return self.__nombre

    # Setter: limpia, valida y guarda el nombre en formato Titulo.
    @nombre.setter
    def nombre(self, valor):
        valor = Cliente.limpiar(valor)
        # El nombre no puede quedar vacio.
        if not valor:
            raise ValueError("El nombre es obligatorio")
        self.__nombre = valor.title()

    # Getter y setter del apellido; se valida igual que el nombre.
    @property
    def apellido(self):
        return self.__apellido

    @apellido.setter
    def apellido(self, valor):
        valor = Cliente.limpiar(valor)
        # Rechaza apellidos vacios antes de guardarlos.
        if not valor:
            raise ValueError("El apellido es obligatorio")
        self.__apellido = valor.title()

    # Getter y setter del email; el setter comprueba el formato y lo normaliza.
    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, valor):
        valor = Cliente.limpiar(valor)
        # Lanza un error si el email no cumple la validacion basica.
        if not Cliente.es_email_valido(valor):
            raise ValueError(f"Email invalido: '{valor}'")
        # Guarda los emails en minusculas para facilitar comparaciones.
        self.__email = valor.lower()

    # Getter y setter del telefono; el setter permite vacio o 10 digitos.
    @property
    def telefono(self):
        return self.__telefono

    @telefono.setter
    def telefono(self, valor):
        valor = Cliente.limpiar(valor)
        # Rechaza cualquier telefono que no cumpla el formato definido.
        if not Cliente.es_telefono_valido(valor):
            raise ValueError("El telefono debe tener 10 digitos o estar vacio")
        self.__telefono = valor

    # Getter y setter de ciudad; se quitan espacios y se capitaliza cada palabra.
    @property
    def ciudad(self):
        return self.__ciudad

    @ciudad.setter
    def ciudad(self, valor):
        self.__ciudad = Cliente.limpiar(valor).title()

    # Getter y setter de direccion; solo elimina espacios externos.
    @property
    def direccion(self):
        return self.__direccion

    @direccion.setter
    def direccion(self, valor):
        self.__direccion = Cliente.limpiar(valor)

    # Propiedad calculada: combina nombre y apellido sin guardarlos de nuevo.
    @property
    def nombre_completo(self):
        return f"{self.__nombre} {self.__apellido}"

    # Propiedad calculada: extrae lo que aparece despues del @ del email.
    @property
    def dominio_email(self):
        return self.__email.split("@")[-1]

    def a_diccionario(self):
        # Crea un diccionario simple para guardar o transferir los datos del cliente.
        return {
            "id": self.__id,
            "nombre": self.__nombre,
            "apellido": self.__apellido,
            "email": self.__email,
            "telefono": self.__telefono,
            "ciudad": self.__ciudad,
            "direccion": self.__direccion,
        }

    def __str__(self):
        # Define el texto que se muestra con print(cliente) o str(cliente).
        return f"[{self.__id}] {self.nombre_completo} - {self.__email}"

    @classmethod
    def desde_diccionario(cls, datos):
        # Reconstruye un objeto usando los datos leidos de un diccionario/JSON.
        # get() permite cargar archivos donde telefono, ciudad o direccion falten.
        return cls(
            datos["id"],
            datos["nombre"],
            datos["apellido"],
            datos["email"],
            datos.get("telefono", ""),
            datos.get("ciudad", ""),
            datos.get("direccion", ""),
        )


class Estudiante:
    """MODELO: un estudiante valido. Si los datos estan mal, el objeto no se crea."""

    # Atributos de clase: se comparten entre todas las instancias de Estudiante.
    CAMPOS = ("nombre", "apellido", "email", "carnet")
    OBLIGATORIOS = ("nombre", "apellido", "email", "carnet")
    # Limites permitidos para las notas y nota minima para aprobar.
    NOTA_MINIMA = 0
    NOTA_MAXIMA = 20
    NOTA_APROBACION = 14
    # Contador compartido de estudiantes creados durante esta ejecucion.
    total_creados = 0

    def __init__(self, id_estudiante, nombre, apellido, email, carnet,
                 notas=None, materias=None):
        # El id se conserva como atributo privado y de solo lectura.
        self.__id = id_estudiante
        # Se asigna por las propiedades para que la validacion corra al crear
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.carnet = carnet
        # Guarda las notas por materia; cada valor es una lista de calificaciones.
        self.__notas = {m: list(n) for m, n in notas.items()} if notas else {}
        # Un conjunto conserva las materias sin duplicados.
        self.__materias = set(materias) if materias else set()
        # Aumenta el contador de instancias creadas.
        Estudiante.total_creados += 1

    # ===== Metodos estaticos: se llaman desde la clase, no requieren un objeto =====
    @staticmethod
    def limpiar(texto):
        # Convierte a texto y elimina espacios exteriores.
        return str(texto).strip()

    @staticmethod
    def es_email_valido(texto):
        # Comprueba una estructura basica de email antes de aceptarla.
        texto = str(texto).strip()
        if texto.count("@") != 1:
            return False
        usuario, dominio = texto.split("@")
        return len(usuario) > 0 and "." in dominio and not dominio.endswith(".")

    @staticmethod
    def es_nota_valida(nota):
        # bool es una subclase de int en Python, por eso se rechaza explicitamente.
        if isinstance(nota, bool) or not isinstance(nota, (int, float)):
            return False
        # La calificacion debe estar entre los limites definidos en la clase.
        return Estudiante.NOTA_MINIMA <= nota <= Estudiante.NOTA_MAXIMA

    # ===== Propiedades: permiten leer atributos y validar cambios con setters =====
    @property
    def id(self):
        # Solo lectura: no tiene setter
        return self.__id

    @property
    def nombre(self):
        # Devuelve el nombre guardado internamente.
        return self.__nombre

    @nombre.setter
    def nombre(self, valor):
        # Quita espacios, rechaza texto vacio y normaliza mayusculas.
        valor = Estudiante.limpiar(valor)
        if not valor:
            raise ValueError("El nombre es obligatorio")
        self.__nombre = valor.title()

    @property
    def apellido(self):
        # Devuelve el apellido guardado internamente.
        return self.__apellido

    @apellido.setter
    def apellido(self, valor):
        # Quita espacios, rechaza texto vacio y normaliza mayusculas.
        valor = Estudiante.limpiar(valor)
        if not valor:
            raise ValueError("El apellido es obligatorio")
        self.__apellido = valor.title()

    @property
    def email(self):
        # Devuelve el email guardado internamente.
        return self.__email

    @email.setter
    def email(self, valor):
        # Limpia, valida y guarda el email siempre en minusculas.
        valor = Estudiante.limpiar(valor)
        if not Estudiante.es_email_valido(valor):
            raise ValueError(f"Email invalido: '{valor}'")
        self.__email = valor.lower()

    @property
    def carnet(self):
        # Devuelve el carnet guardado internamente.
        return self.__carnet

    @carnet.setter
    def carnet(self, valor):
        # El carnet se normaliza a mayusculas y debe tener al menos 4 caracteres.
        valor = Estudiante.limpiar(valor).upper()
        if len(valor) < 4:
            raise ValueError("El carnet debe tener al menos 4 caracteres")
        self.__carnet = valor

    @property
    def materias(self):
        # Copia, para que nadie cambie el conjunto interno desde afuera
        return set(self.__materias)

    @property
    def notas(self):
        # Devuelve una copia del diccionario y de sus listas para proteger los datos.
        return {m: list(n) for m, n in self.__notas.items()}

    # ===== Propiedades calculadas: su valor se obtiene a partir de otros datos =====
    @property
    def nombre_completo(self):
        # Une el nombre y el apellido para mostrar el nombre completo.
        return f"{self.__nombre} {self.__apellido}"

    @property
    def promedio(self):
        # Junta las notas de todas las materias en una sola lista.
        todas = []
        for lista_notas in self.__notas.values():
            todas.extend(lista_notas)
        # Si aun no hay notas, el promedio se considera 0.
        if not todas:
            return 0
        # Calcula el promedio y lo redondea a dos decimales.
        return round(sum(todas) / len(todas), 2)

    @property
    def estado(self):
        # Compara el promedio con la nota minima de aprobacion.
        if self.promedio >= Estudiante.NOTA_APROBACION:
            return "Aprobado"
        return "Reprobado"

    # ===== Metodos de instancia: operan sobre los datos de este estudiante =====
    def inscribir_materia(self, materia):
        # Limpia y normaliza el nombre de la materia.
        materia = Estudiante.limpiar(materia).title()
        # No se permite inscribir una materia vacia.
        if not materia:
            raise ValueError("La materia no puede estar vacia")
        # add() agrega al conjunto o no hace nada si ya estaba inscrita.
        self.__materias.add(materia)
        return materia

    def agregar_nota(self, materia, nota):
        # Verifica el tipo y el rango de la nota antes de modificar los datos.
        if not Estudiante.es_nota_valida(nota):
            raise ValueError(
                f"La nota debe estar entre {Estudiante.NOTA_MINIMA} "
                f"y {Estudiante.NOTA_MAXIMA}"
            )
        # Inscribe la materia si hace falta y obtiene su nombre normalizado.
        materia = self.inscribir_materia(materia)
        # Crea la lista de notas si es nueva y agrega la calificacion al final.
        self.__notas.setdefault(materia, []).append(nota)

    def notas_de(self, materia):
        # Devuelve una copia de las notas de esa materia, o una lista vacia.
        return list(self.__notas.get(Estudiante.limpiar(materia).title(), []))

    def materias_en_comun(self, otro):
        # Devuelve la interseccion: materias que cursan ambos estudiantes.
        return self.__materias & otro.materias

    def a_diccionario(self):
        # Convierte el objeto a tipos que se pueden serializar como JSON.
        return {
            "id": self.__id,
            "nombre": self.__nombre,
            "apellido": self.__apellido,
            "email": self.__email,
            "carnet": self.__carnet,
            "notas": self.__notas,
            "materias": sorted(self.__materias),  # JSON no guarda sets
        }

    def __str__(self):
        # Texto legible que se muestra al imprimir el estudiante.
        return f"[{self.__carnet}] {self.nombre_completo} - Promedio: {self.promedio}"

    # ===== Metodo de clase: recibe la clase para poder construir una instancia =====
    @classmethod
    def desde_diccionario(cls, datos):
        # Crea un estudiante a partir de datos cargados desde un diccionario/JSON.
        return cls(
            datos["id"],
            datos["nombre"],
            datos["apellido"],
            datos["email"],
            datos["carnet"],
            notas=datos.get("notas", {}),
            materias=set(datos.get("materias", [])),  # lista -> conjunto
        )


if __name__ == "__main__":
    # Prueba rapida del modelo: python models.py
    # Estos ejemplos solo se ejecutan cuando este archivo se corre directamente.
    est1 = Estudiante(1, "  ana ", "perez", "ANA@unemi.edu.ec", "est2026001")
    est2 = Estudiante(2, "Luis", "Mora", "luis@unemi.edu.ec", "EST2026002")

    # Muestra como se limpian y normalizan los datos al construir el objeto.
    print(est1.nombre, est1.email, est1.carnet)
    # Comprueba el resultado cuando aun no se han agregado calificaciones.
    print("Promedio sin notas:", est1.promedio)

    # Inscribir dos veces la misma materia no crea duplicados en el conjunto.
    est1.inscribir_materia("Fisica")
    est1.inscribir_materia("Fisica")
    print("Materias (sin repetir):", est1.materias)

    # Agrega varias notas y materias para probar promedio y estado.
    est1.agregar_nota("Matematica", 18)
    est1.agregar_nota("Matematica", 19)
    est1.agregar_nota("Ingles", 17)
    est2.agregar_nota("Matematica", 15)
    # Muestra las notas, el promedio, el estado y las materias compartidas.
    print("Notas:", est1.notas)
    print("Promedio:", est1.promedio, "-", est1.estado)
    print("En comun:", est1.materias_en_comun(est2))

    # Convierte a diccionario y reconstruye el objeto para probar ambas conversiones.
    copia = Estudiante.desde_diccionario(est1.a_diccionario())
    print("Reconstruido:", copia)

    # Prueba que una nota fuera del rango se rechaza con ValueError.
    try:
        est1.agregar_nota("Matematica", 25)
    except ValueError as error:
        print("Nota invalida rechazada:", error)
