import os

# Codigos ANSI para colorear mensajes; RESET vuelve al color normal.
COLORES = {
    "ROJO": "\033[91m",
    "VERDE": "\033[92m",
    "AZUL": "\033[94m",
    "AMARILLO": "\033[93m",
    "CYAN": "\033[96m",
    "BLANCO": "\033[97m",
    "RESET": "\033[0m",
}

# Respuestas que la funcion confirmar considera afirmativas.
RESPUESTAS_SI = ("si", "sí", "s", "yes", "y")


def limpiar_pantalla():
    """Limpia la consola usando el comando correspondiente al sistema operativo."""
    os.system("cls" if os.name == "nt" else "clear")


def imprimir_color(texto, color):
    """Imprime texto con un color conocido o blanco como valor predeterminado."""
    codigo = COLORES.get(color, COLORES["BLANCO"])
    print(f"{codigo}{texto}{COLORES['RESET']}")


def imprimir_titulo(texto):
    """Limpia la pantalla y dibuja un titulo centrado entre lineas."""
    limpiar_pantalla()
    imprimir_color("=" * 60, "AZUL")
    print(texto.center(60))
    imprimir_color("=" * 60, "AZUL")
    print()


def imprimir_exito(mensaje):
    """Muestra un mensaje positivo en verde."""
    imprimir_color(f"OK: {mensaje}", "VERDE")


def imprimir_error(mensaje):
    """Muestra un mensaje de error en rojo."""
    imprimir_color(f"Error: {mensaje}", "ROJO")


def imprimir_info(mensaje):
    """Muestra informacion general en cyan."""
    imprimir_color(mensaje, "CYAN")


def confirmar(pregunta):
    """Pregunta si/no y devuelve True solo para las respuestas afirmativas admitidas."""
    respuesta = input(f"{pregunta} (si/no): ").strip().lower()
    return respuesta in RESPUESTAS_SI
