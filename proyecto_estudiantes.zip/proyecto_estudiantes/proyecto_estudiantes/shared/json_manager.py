import json
import os


class GestorJSON:
    """Lee y guarda una lista de diccionarios en un archivo JSON.
    Es la unica parte del programa que toca el disco."""

    def __init__(self, ruta):
        # La ruta es privada para que solo se consulte mediante la propiedad.
        self.__ruta = ruta
        # Crea la carpeta padre si todavía no existe.
        carpeta = os.path.dirname(ruta)
        if carpeta and not os.path.exists(carpeta):
            os.makedirs(carpeta)

    @property
    def ruta(self):
        """Devuelve la ruta del archivo sin permitir cambiarla desde afuera."""
        return self.__ruta

    def leer(self):
        """Lee una lista JSON; ante archivo ausente o dañado devuelve una lista vacia."""
        # Un archivo nuevo todavía no contiene registros.
        if not os.path.exists(self.__ruta):
            return []
        try:
            # with cierra el archivo automaticamente incluso si ocurre un error.
            with open(self.__ruta, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)
            # El programa espera una lista en la raiz del archivo.
            return datos if isinstance(datos, list) else []
        except (json.JSONDecodeError, OSError):
            # Un JSON invalido o un problema de lectura no detiene la aplicacion.
            return []

    def guardar(self, datos):
        """Escribe datos como JSON y devuelve False si no se pueden serializar o guardar."""
        try:
            # UTF-8 conserva caracteres como tildes; indent mejora la legibilidad.
            with open(self.__ruta, "w", encoding="utf-8") as archivo:
                json.dump(datos, archivo, ensure_ascii=False, indent=2)
            return True
        except (TypeError, OSError):
            return False
